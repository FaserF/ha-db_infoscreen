DOMAIN = "db_infoscreen"
GITHUB_ISSUES_URL: str = "https://github.com/FaserF/ha-db_infoscreen/issues"
CONF_SERVER_TYPE = "server_type"
CONF_SERVER_URL = "server_url"
CONF_CACHE_TTL = "cache_ttl"
DEFAULT_CACHE_TTL = 55
SERVER_TYPE_CUSTOM = "custom"
SERVER_TYPE_OFFICIAL = "official"
SERVER_TYPE_FASERF = "faserf"
SERVER_URL_OFFICIAL = "https://dbf.finalrewind.org"
SERVER_URL_FASERF = "https://dbf.fabiseitz.de"

CONF_STATION = "station"
CONF_NEXT_DEPARTURES = "next_departures"
CONF_UPDATE_INTERVAL = "update_interval"
DEFAULT_NEXT_DEPARTURES = 4
DEFAULT_UPDATE_INTERVAL = 3
MIN_UPDATE_INTERVAL = 0
MAX_SENSORS = 30

CONF_HIDE_LOW_DELAY = "hidelowdelay"
CONF_DETAILED = "detailed"
CONF_PAST_60_MINUTES = "past_60_minutes"
CONF_DATA_SOURCE = "data_source"
CONF_OFFSET = "offset"
DEFAULT_OFFSET = "00:00"
CONF_PLATFORMS = "platforms"
CONF_ADMODE = "admode"
CONF_VIA_STATIONS = "via_stations"
CONF_VIA_STATIONS_LOGIC = "via_stations_logic"
CONF_DIRECTION = "direction"
CONF_EXCLUDED_DIRECTIONS = "excluded_directions"
CONF_IGNORED_TRAINTYPES = "ignored_train_types"
CONF_DROP_LATE_TRAINS = "drop_late_trains"
CONF_KEEP_ROUTE = "keep_route"
CONF_KEEP_ENDSTATION = "keep_endstation"
CONF_DEDUPLICATE_DEPARTURES = "deduplicate_departures"
CONF_DEDUPLICATE_KEY = "deduplicate_key"
DEFAULT_DEDUPLICATE_KEY = "{journeyID}{journeyId}{id}{key}{trainNumber}"
CONF_ENABLE_TEXT_VIEW = "enable_text_view"
CONF_TEXT_VIEW_TEMPLATE = "text_view_template"
DEFAULT_TEXT_VIEW_TEMPLATE = (
    "{line} -> {destination} (Pl {platform}): {time}{delay_str}"
)
CONF_EXCLUDE_CANCELLED = "exclude_cancelled"
CONF_FAVORITE_TRAINS = "favorite_trains"
CONF_WALK_TIME = "walk_time"
CONF_PAUSED = "paused"
CONF_CALENDAR_EVENT_DURATION = "calendar_event_duration"
CONF_CALENDAR_ONLY_FAVORITES = "calendar_only_favorites"
CONF_CALENDAR_ONLY_DELAYED = "calendar_only_delayed"
DEFAULT_CALENDAR_EVENT_DURATION = 5

TRAIN_TYPE_MAPPING = {
    "S": "s_bahn",
    "N": "regional_db",
    "D": "regional",
    "F": "long_distance",
    "Unknown": "unknown",
    "": "unknown",
    # HAFAS / Common classes
    "ICE": "long_distance",
    "IC": "long_distance",
    "EC": "long_distance",
    "TGV": "long_distance",
    "RJ": "long_distance",
    "RJX": "long_distance",
    "NJ": "long_distance",
    "RE": "regional_db",
    "RB": "regional_db",
    "S-Bahn": "s_bahn",
    "U-Bahn": "u_bahn",
    "Tram": "tram",
    "Bus": "bus",
    "Stadtbus": "bus",
    "Metrobus": "bus",
    "Unbekannter Zugtyp": "unknown",
}

DATA_SOURCE_MAP = {
    "AVV – Aachener Verkehrsverbund": "hafas=AVV",
    "AVV – Augsburger Verkehrs- & Tarifverbund": "efa=AVV",
    "BART – Bay Area Rapid Transit": "hafas=BART",
    "BEG – Bayerische Eisenbahngesellschaft": "efa=BEG",
    "BLS – BLS AG": "hafas=BLS",
    "BSVG – Braunschweiger Verkehrs-GmbH": "efa=BSVG",
    "BVG – Berliner Verkehrsbetriebe": "hafas=BVG",
    "CFL – Société Nationale des Chemins de Fer Luxembourgeois": "hafas=CFL",
    "CMTA – Capital Metro Austin Public Transport": "hafas=CMTA",
    "DING – Donau-Iller Nahverkehrsverbund": "efa=DING",
    "DSB – Rejseplanen": "hafas=DSB",
    "IE – Iarnród Éireann": "hafas=IE",
    "KVB – Kölner Verkehrs-Betriebe": "hafas=KVB",
    "KVV – Karlsruher Verkehrsverbund": "efa=KVV",
    "LinzAG – Linz AG": "efa=LinzAG",
    "MVV – Münchener Verkehrs- und Tarifverbund": "efa=MVV",
    "NAHSH – Nahverkehrsverbund Schleswig-Holstein": "hafas=NAHSH",
    "NASA – Personennahverkehr in Sachsen-Anhalt": "hafas=NASA",
    "NVBW – Nahverkehrsgesellschaft Baden-Württemberg": "efa=NVBW",
    "NVV – Nordhessischer Verkehrsverbund": "hafas=NVV",
    "NWL – Nahverkehr Westfalen-Lippe": "efa=NWL",
    "PKP – Polskie Koleje Państwowe": "hafas=PKP",
    "RMV – Rhein-Main-Verkehrsverbund": "hafas=RMV",
    "RSAG – Rostocker Straßenbahn": "hafas=RSAG",
    "RVV – Regensburger Verkehrsverbund": "efa=RVV",
    "Resrobot – Resrobot": "hafas=Resrobot",
    "Rolph – Rolph": "efa=Rolph",
    "STV – Steirischer Verkehrsverbund": "hafas=STV",
    "SaarVV – Saarländischer Verkehrsverbund": "hafas=SaarVV",
    "TPG – Transports publics genevois": "hafas=TPG",
    "VAG – Freiburger Verkehrs AG": "efa=VAG",
    "VBB – Verkehrsverbund Berlin-Brandenburg": "hafas=VBB",
    "VBN – Verkehrsverbund Bremen/Niedersachsen": "hafas=VBN",
    "VGN – Verkehrsverbund Großraum Nürnberg": "efa=VGN",
    "VMT – Verkehrsverbund Mittelthüringen": "hafas=VMT",
    "VMV – Verkehrsgesellschaft Mecklenburg-Vorpommern": "efa=VMV",
    "VOS – Verkehrsgemeinschaft Osnabrück": "hafas=VOS",
    "VRN – Verkehrsverbund Rhein-Neckar": "efa=VRN",
    "VRR – Verkehrsverbund Rhein-Ruhr": "efa=VRR",
    "VRR2 – Verkehrsverbund Rhein-Ruhr": "efa=VRR2",
    "VRR3 – Verkehrsverbund Rhein-Ruhr": "efa=VRR3",
    "VVO – Verkehrsverbund Oberelbe": "efa=VVO",
    "VVS – Verkehrs- und Tarifverbund Stuttgart": "efa=VVS",
    "ZVV – Züricher Verkehrsverbund": "hafas=ZVV",
    "bwegt – bwegt": "efa=bwegt",
    "mobiliteit – mobilitéits zentral": "hafas=mobiliteit",
    "ÖBB – Österreichische Bundesbahnen": "hafas=ÖBB",
}

DATA_SOURCE_OPTIONS = ["IRIS-TTS", "hafas=1"] + sorted(DATA_SOURCE_MAP.keys())


def normalize_data_source(value: str) -> str:
    """Normalize legacy data source values to descriptive keys."""
    if value in DATA_SOURCE_OPTIONS:
        return value

    if value == "hafas=1":
        return "hafas=1"

    # First check for exact value match in the map to avoid ambiguity
    # e.g. "hafas=AVV" should match "AVV – Aachener Verkehrsverbund" directly
    for option, mapped_val in DATA_SOURCE_MAP.items():
        if mapped_val == value:
            return option

    # Handle patterns: exact code -> find matching key using exact check
    # e.g., "NVBW" or "efa=NVBW"
    code = value
    if "=" in value:
        code = value.split("=", 1)[1]

    matches = []
    for option, mapped_val in DATA_SOURCE_MAP.items():
        # Exact match of the full mapped value or exact match of the part after '='
        if mapped_val == value or (
            mapped_val.endswith("=" + code) and "=" in mapped_val
        ):
            matches.append(option)

    if len(matches) == 1:
        return matches[0]

    # Special handling for common ambiguous codes like AVV
    if value == "AVV" or value == "efa=AVV":
        return "AVV – Augsburger Verkehrs- & Tarifverbund"
    if value == "hafas=AVV":
        return "AVV – Aachener Verkehrsverbund"

    return value


IGNORED_TRAINTYPES_OPTIONS = {
    "S": "Stadtbahn (S-Bahn)",
    "U-Bahn": "Untergrundbahn (U-Bahn)",
    "StadtBus": "Stadtbus",
    "N": "Regional Bahn (RB), Regional Express (RE)",
    "D": "Andere Regionalbahn (z.B. BRB, Wiener Bahn)",
    "F": "EuroCity (EC), Intercity Express (ICE), Intercity (IC)",
    "Unbekannter Zugtyp": "Unbekannter Zugtyp",
}

CONF_SHOW_OCCUPANCY = "show_occupancy"
