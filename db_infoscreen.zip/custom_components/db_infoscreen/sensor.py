"""Sensor platform for DB Infoscreen integration."""

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from typing import Any, cast
from .const import (
    DOMAIN,
    CONF_ENABLE_TEXT_VIEW,
    CONF_WALK_TIME,
    CONF_TEXT_VIEW_TEMPLATE,
    DEFAULT_TEXT_VIEW_TEMPLATE,
)
from .entity import DBInfoScreenBaseEntity
from .utils import parse_datetime_flexible
import logging
from homeassistant.util import dt as dt_util

_LOGGER = logging.getLogger(__name__)

MAX_LENGTH = 70


class DBInfoSensor(DBInfoScreenBaseEntity, SensorEntity):
    """
    Main sensor for displaying next departures at a station.

    Supports optional filtering by platform, via stations, and direction.
    Can also display a formatted text view for simple displays.
    """

    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator,
        config_entry,
        station,
        via_stations,
        direction,
        platforms,
        enable_text_view,
    ):
        """Initialize the sensor."""
        super().__init__(coordinator, config_entry)
        self.via_stations = via_stations
        self.direction = direction
        self.platforms = platforms
        self.enable_text_view = enable_text_view

        platforms_suffix_name = f" platform {platforms}" if platforms else ""
        via_suffix_name = f" via {' '.join(via_stations)}" if via_stations else ""
        direction_suffix_name = f" direction {self.direction}" if self.direction else ""

        # Entity name
        self._attr_translation_key = "departures"
        self._attr_name = (
            f"Departures{platforms_suffix_name}{via_suffix_name}{direction_suffix_name}"
        )

        if len(self._attr_name) > MAX_LENGTH:
            self._attr_name = self._attr_name[:MAX_LENGTH]

        # Unique ID
        self._attr_unique_id = f"db_infoscreen_{config_entry.entry_id}"
        self._attr_icon = "mdi:train"

        # Initial value
        self._last_valid_value = None

        _LOGGER.debug(
            "DBInfoSensor initialized for station: %s, via_stations: %s, direction: %s, unique_id: %s, name: %s",
            station,
            via_stations,
            direction,
            self._attr_unique_id,
            self._attr_name,
        )

    def format_departure_time(self, departure_time: Any) -> str | None:
        """Format a departure time using centralized robust parsing."""
        if departure_time is None:
            return None

        now = dt_util.now()
        today = now.date()

        dt_val = parse_datetime_flexible(departure_time, now)

        if not dt_val:
            return None

        if dt_val.date() != today:
            return dt_val.strftime("%Y-%m-%d %H:%M")
        return dt_val.strftime("%H:%M")

    def _get_filtered_departures(self):
        """
        Filter out departures based on time and sensor-specific settings.
        Also applies filtering for platforms, direction, and via stations.
        """
        now = dt_util.now().timestamp()
        raw_departures: list[dict[str, Any]] = cast(
            list[dict[str, Any]], self.coordinator.data or []
        )
        # 1. Time filtering (keep future and very recent past trains)
        filtered = [
            dep
            for dep in raw_departures
            if dep.get("departure_timestamp", 0) > (now - 30)
        ]

        # 2. Platform filtering
        if self.platforms:
            platforms = [p.strip() for p in str(self.platforms).split(",")]
            filtered = [
                dep for dep in filtered if str(dep.get("platform")) in platforms
            ]

        return filtered

    @property
    def native_value(self) -> str | None:
        """
        Return the main state of the sensor (e.g., '10:30' or '10:30 +5').

        Calculates the state from the first entry in the filtered data.
        """
        departures: list[dict[str, Any]] = self._get_filtered_departures()

        # Find the first non-cancelled departure for the main state
        main_departure = None
        for dep in departures:
            if not dep.get("is_cancelled", False):
                main_departure = dep
                break

        # Check if there is data and if it is valid
        if main_departure:
            try:
                # Try to get the scheduled departure time
                departure_time = (
                    main_departure.get("scheduledDeparture")
                    or main_departure.get("sched_dep")
                    or main_departure.get("scheduledArrival")
                    or main_departure.get("sched_arr")
                    or main_departure.get("scheduledTime")
                    or main_departure.get("dep")
                    or main_departure.get("datetime")
                )

                # Use normalized fields from coordinator
                delay_departure = main_departure.get("delay", 0)

                _LOGGER.debug("Raw departure time: %s", departure_time)

                # Use the admode from coordinator to determine the display format
                admode = getattr(self.coordinator, "admode", "preferred departure")

                if admode == "preferred departure":
                    # For preferred departure, show actual time (scheduled + delay)
                    # departure_timestamp already includes the delay
                    actual_time = main_departure.get("departure_timestamp")
                    departure_time = self.format_departure_time(actual_time)

                    if departure_time is None:
                        _LOGGER.debug(
                            "Formatted departure time is None, skipping update."
                        )
                        return self._last_valid_value or "invalid_time"

                    self._last_valid_value = departure_time
                else:
                    # For "departure" and "arrival" modes, show scheduled time + delay notation
                    departure_time = self.format_departure_time(departure_time)
                    if departure_time is None:
                        _LOGGER.debug(
                            "Formatted departure time is None, skipping update."
                        )
                        return self._last_valid_value or "invalid_time"

                    if delay_departure in (0, None, "None"):
                        self._last_valid_value = departure_time
                    else:
                        departure_time = f"{departure_time} +{delay_departure}"
                        self._last_valid_value = departure_time

                _LOGGER.debug("Sensor state updated: %s", self._last_valid_value)
                return self._last_valid_value
            except Exception as e:
                _LOGGER.error("Exception during data parsing: %s", e)
                return self._last_valid_value or "error"
        else:
            # If no new data is available, return the last valid value or a fallback value
            if self._last_valid_value:
                _LOGGER.warning(
                    "No departures found for station: %s. Keeping previous value: %s.",
                    self.station,
                    self._last_valid_value,
                )
                return self._last_valid_value
            else:
                # If no data and no previous valid value, return a fallback message
                _LOGGER.warning(
                    "No departures found for station: %s. No previous value available.",
                    self.station,
                )
                return "no_data"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """
        Return additional state attributes for the sensor including next departures and metadata.
        """
        full_api_url = getattr(self.coordinator, "_base_url", "dbf.finalrewind.org")
        attribution = f"Data provided by API {full_api_url}"

        # Create a deep copy or new list of dicts to avoid mutating the coordinator data
        raw_departures: list[dict[str, Any]] = self._get_filtered_departures()
        next_departures = []

        for departure in raw_departures:
            # Create a shallow copy of the departure so we can modify fields for display
            dep_copy = departure.copy()

            if "scheduledTime" in dep_copy and isinstance(
                dep_copy["scheduledTime"], (int, float)
            ):
                dep_copy["scheduledTime"] = dt_util.as_local(
                    dt_util.utc_from_timestamp(int(dep_copy["scheduledTime"]))
                ).strftime("%Y-%m-%d %H:%M:%S")
            if "time" in dep_copy and isinstance(dep_copy["time"], (int, float)):
                dep_copy["time"] = dt_util.as_local(
                    dt_util.utc_from_timestamp(int(dep_copy["time"]))
                ).strftime("%Y-%m-%d %H:%M:%S")

            next_departures.append(dep_copy)

        last_updated = getattr(self.coordinator, "last_update", None)
        if last_updated:
            last_updated = last_updated.isoformat()
        else:
            last_updated = "Unknown"

        attributes = {
            "next_departures": next_departures,
            "station": self.station,
            "via_stations": self.via_stations,
            "direction": self.direction,
            "last_updated": last_updated,
            "attribution": attribution,
            "is_paused": getattr(self.coordinator, "paused", False),
            "via_stations_logic": getattr(self.coordinator, "via_stations_logic", "OR"),
            "station_messages": getattr(self.coordinator, "station_messages", []),
        }

        if self.enable_text_view:
            next_departures_text = []
            for dep in raw_departures:
                line = dep.get("line", "?")
                destination = dep.get("destination", "?")
                platform = dep.get("platform", "?")
                time = (
                    dep.get("time")
                    or dep.get("departure_current")
                    or dep.get("scheduledDeparture")
                    or dep.get("sched_dep")
                    or dep.get("datetime")
                    or "?"
                )
                delay = dep.get("delay", 0)

                # Format time if it is an int/timestamp, otherwise use as is
                if isinstance(time, (int, float)):
                    time = dt_util.as_local(
                        dt_util.utc_from_timestamp(int(time))
                    ).strftime("%H:%M")

                delay_str = ""
                if delay:
                    try:
                        if int(delay) > 0:
                            delay_str = f" +{delay}"
                    except (ValueError, TypeError):
                        pass

                class SafeDict(dict):
                    def __missing__(self, key):
                        return "{" + str(key) + "}"

                format_dict = {
                    "line": line,
                    "destination": destination,
                    "platform": platform,
                    "time": time,
                    "delay": delay if delay else "",
                    "delay_str": delay_str,
                }

                template = self.config_entry.options.get(
                    CONF_TEXT_VIEW_TEMPLATE, DEFAULT_TEXT_VIEW_TEMPLATE
                )

                try:
                    text = template.format_map(SafeDict(format_dict))
                except Exception as e:
                    _LOGGER.warning("Failed to format next_departures_text: %s", e)
                    text = f"{line} -> {destination} (Pl {platform}): {time}{delay_str}"

                next_departures_text.append(text)
            attributes["next_departures_text"] = next_departures_text

        return attributes

    async def async_update(self):
        _LOGGER.debug("Sensor update triggered but not forcing refresh.")

    async def async_added_to_hass(self):
        _LOGGER.debug(
            "Sensor added to Home Assistant for station: %s, via_stations: %s",
            self.station,
            self.via_stations,
        )
        self.async_on_remove(
            self.coordinator.async_add_listener(self.async_write_ha_state)
        )
        _LOGGER.debug(
            "Listener attached for station: %s, via_stations: %s",
            self.station,
            self.via_stations,
        )


class DBInfoScreenWatchdogSensor(DBInfoScreenBaseEntity, SensorEntity):
    """
    Diagnostic sensor that monitors the status of the upcoming trip.

    Looks at the previous station of the next departing train to see if it
    is on time or delayed earlier in its route.
    """

    _attr_has_entity_name = True
    _attr_icon = "mdi:eye-check-outline"
    _attr_entity_registry_enabled_default = False  # Optional feature

    def __init__(self, coordinator, config_entry: ConfigEntry) -> None:
        """Initialize the watchdog sensor."""
        super().__init__(coordinator, config_entry)
        self._attr_unique_id = f"db_infoscreen_watchdog_{config_entry.entry_id}"
        self._attr_translation_key = "trip_watchdog"

    @property
    def native_value(self) -> str | None:
        """
        Return the current watchdog state.

        Shows the name and delay of the previous station for the next train.
        """
        data = self._get_watchdog_data()
        if data:
            station = data.get("previous_station_name")
            delay = data.get("previous_delay", 0)

            if station:
                if delay and delay > 0:
                    return f"{station}: +{delay} min"
                return f"{station}: On Time"

        # Provide more descriptive fallbacks than just "Unknown"
        if not self.coordinator.data:
            return "No Departures"

        # Check for first departure since that's what we watch
        coord_data = cast(list[dict[str, Any]], self.coordinator.data)
        next_train = coord_data[0] if coord_data else {}
        if not getattr(self.coordinator, "detailed", False):
            return "Enable Detailed Data"

        route = next_train.get("route", [])
        if not route:
            return "No Route Data"

        # If we are here, matching failed or we are at index 0
        return "Trip Origin / First Stop"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return details about the watched trip."""
        return self._get_watchdog_data() or {}

    def _get_watchdog_data(self) -> dict[str, Any] | None:
        """Calculate watchdog data from the first departure."""
        departures: list[dict[str, Any]] = cast(
            list[dict[str, Any]], self.coordinator.data or []
        )
        if not departures:
            return None

        # Look at the first (next) departure
        next_train: dict[str, Any] = departures[0]
        route = next_train.get("route", [])

        if not route:
            return None

        if self.coordinator.config_entry is None:
            return None

        my_station_name = str(self.station)
        my_display_name = (
            str(self.config_entry.title) if self.config_entry.title else ""
        )

        found_index = -1
        for idx, stop in enumerate(route):
            stop_name = stop.get("name", "") if isinstance(stop, dict) else str(stop)
            if not stop_name:
                continue

            # Robust matching: Exact, Partial, or Config Title
            if (
                stop_name.lower() == my_station_name.lower()
                or stop_name.lower() == my_display_name.lower()
                or (
                    my_station_name.lower()
                    and my_station_name.lower() in stop_name.lower()
                )
                or (
                    my_display_name.lower()
                    and my_display_name.lower() in stop_name.lower()
                )
            ):
                found_index = idx
                _LOGGER.debug(
                    "Matched station '%s' in route at index %d (Match criteria: %s / %s)",
                    stop_name,
                    idx,
                    my_station_name,
                    my_display_name,
                )
                break

        if found_index > 0:
            prev_stop = route[found_index - 1]
            prev_name = (
                prev_stop.get("name") if isinstance(prev_stop, dict) else str(prev_stop)
            )
            # dep_delay is delay at departure from that stop
            # arr_delay is delay at arrival at that stop
            delay = 0
            if isinstance(prev_stop, dict):
                delay = prev_stop.get("dep_delay") or prev_stop.get("arr_delay") or 0

            return {
                "train": next_train.get("train"),
                "current_station_index": found_index,
                "previous_station_name": prev_name,
                "previous_delay": int(delay) if delay else 0,
                "updated": getattr(self.coordinator, "last_update", None),
            }

        _LOGGER.debug(
            "Watchdog: Station '%s' (%s) not found in route or is first stop (found_index=%d). Route: %s",
            my_station_name,
            my_display_name,
            found_index,
            [s.get("name") if isinstance(s, dict) else s for s in route[:5]],
        )
        return None


class DBInfoScreenLeaveNowSensor(DBInfoScreenBaseEntity, SensorEntity):
    """
    Utility sensor that calculates the minutes remaining until you must leave.

    Subtracts the configured 'walk time' from the next train's departure time.
    """

    _attr_has_entity_name = True
    _attr_translation_key = "leave_now"
    _attr_entity_registry_enabled_default = False  # Disabled by default
    _attr_native_unit_of_measurement = "min"

    def __init__(self, coordinator, config_entry):
        super().__init__(coordinator, config_entry)
        self._attr_unique_id = f"leave_now_{config_entry.entry_id}"
        self._attr_icon = "mdi:walk"

    @property
    def walk_time(self):
        """Get the walk time from config data or options."""
        # Options override data. 0 is a valid value, so check explicitly for None.
        opt = self.config_entry.options.get(CONF_WALK_TIME)
        if opt is not None:
            return opt
        return self.config_entry.data.get(CONF_WALK_TIME, 0)

    def _get_next_departure(self):
        """Get the next non-cancelled departure."""
        if not self.coordinator.data or not isinstance(self.coordinator.data, list):
            return None

        for dep in self.coordinator.data:
            if not dep.get("is_cancelled", False):
                return dep
        return None

    @property
    def native_value(self):
        """
        Return the number of minutes until the user must leave.

        Returns 'Leave now!' if the walk time has already passed.
        """
        next_dep = self._get_next_departure()
        if not next_dep:
            return None

        departure_timestamp = next_dep.get("departure_timestamp")

        if not departure_timestamp:
            return None

        now = dt_util.now().timestamp()
        minutes_until_departure = (departure_timestamp - now) / 60
        minutes_until_leave = int(minutes_until_departure - self.walk_time)

        if minutes_until_leave <= 0:
            return 0

        return int(minutes_until_leave)

    @property
    def extra_state_attributes(self):
        next_dep = self._get_next_departure()
        if not next_dep:
            return {}

        departure_timestamp = next_dep.get("departure_timestamp")
        if not departure_timestamp:
            return {
                "train": next_dep.get("train"),
                "destination": next_dep.get("destination"),
                "departure_time": next_dep.get("departure_current"),
                "walk_time": self.walk_time,
                "next_departures_count": len(self.coordinator.data),
                "status": None,
            }

        minutes_until_departure = (departure_timestamp - dt_util.now().timestamp()) / 60
        minutes_until_leave = int(minutes_until_departure - self.walk_time)
        status = "Leave now!" if minutes_until_leave <= 0 else "On time"

        return {
            "train": next_dep.get("train"),
            "destination": next_dep.get("destination"),
            "departure_time": next_dep.get("departure_current"),
            "walk_time": self.walk_time,
            "next_departures_count": len(self.coordinator.data),
            "status": status,
        }


class DBInfoScreenPunctualitySensor(DBInfoScreenBaseEntity, SensorEntity):
    """
    Statistical sensor for station punctuality.

    Displays the percentage of trains that were on time (delay <= 5 min)
    over the last 24 hours.
    """

    _attr_has_entity_name = True
    _attr_translation_key = "punctuality"
    _attr_entity_registry_enabled_default = False  # Disabled by default
    _attr_native_unit_of_measurement = "%"

    def __init__(self, coordinator, config_entry):
        super().__init__(coordinator, config_entry)
        self._attr_unique_id = f"punctuality_{config_entry.entry_id}"
        self._attr_icon = "mdi:chart-line"

    @property
    def native_value(self):
        """Return the calculated punctuality percentage."""
        stats = self._get_stats()
        return stats.get("punctuality_percent")

    @property
    def extra_state_attributes(self):
        return self._get_stats()

    def _get_stats(self):
        """Calculate statistics from history."""
        history = getattr(self.coordinator, "departure_history", {})
        if not history:
            return {
                "punctuality_percent": 100.0,
                "total_trains": 0,
                "delayed_trains": 0,
                "cancelled_trains": 0,
                "average_delay": 0.0,
            }

        total = len(history)
        delayed = sum(
            1
            for d in history.values()
            if d.get("delay", 0) > 5 and not d.get("is_cancelled", False)
        )
        cancelled = sum(1 for d in history.values() if d.get("is_cancelled", False))
        on_time = total - delayed - cancelled

        punctuality = round((on_time / total) * 100, 1) if total > 0 else 100.0

        total_delay = sum(
            d.get("delay", 0)
            for d in history.values()
            if not d.get("is_cancelled", False)
        )
        avg_delay = (
            round(total_delay / (total - cancelled), 1)
            if (total - cancelled) > 0
            else 0.0
        )

        return {
            "punctuality_percent": punctuality,
            "total_trains": total,
            "delayed_trains": delayed,
            "cancelled_trains": cancelled,
            "average_delay": avg_delay,
        }


async def async_setup_entry(hass, config_entry, async_add_entities):
    """
    Set up a DBInfoSensor entity for the given config entry.
    """
    coordinator = hass.data[DOMAIN][config_entry.entry_id]

    # Prioritize options over data
    conf = {**config_entry.data, **config_entry.options}

    station = conf.get("station")
    via_stations = conf.get("via_stations", [])
    direction = conf.get("direction", "")
    platforms = conf.get("platforms", "")
    enable_text_view = conf.get(CONF_ENABLE_TEXT_VIEW, False)

    _LOGGER.debug("Setting up DBInfoScreen sensors for station: %s", station)

    entities = [
        DBInfoSensor(
            coordinator,
            config_entry,
            station,
            via_stations,
            direction,
            platforms,
            enable_text_view,
        ),
        DBInfoScreenWatchdogSensor(coordinator, config_entry),
        DBInfoScreenLeaveNowSensor(coordinator, config_entry),
        DBInfoScreenPunctualitySensor(coordinator, config_entry),
    ]

    async_add_entities(entities)
